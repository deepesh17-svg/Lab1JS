// Function to read the contents of the text file asynchronously
const readTextFile = (filePath) => {
    return new Promise((resolve, reject) => {
        fetch(filePath)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(text => resolve(text))
            .catch(error => reject(error));
    });
};

// Path to the text file
const filePath = 'ECMAScript.txt';

// Function to render the content of the text file on the HTML page
const renderContent = async () => {
    try {
        // Reading the text file content
        const fileContent = await readTextFile(filePath);

        // Accessing the content div
        const contentDiv = document.getElementById('fileContent');

        // Setting the content of the div to the file content
        contentDiv.innerHTML = `<h2>Text File Content</h2><p>${fileContent}</p>`;
    } catch (error) {
        console.error('Error:', error);
    }
};

// Calling the function to render content
renderContent().catch(error => console.error('Rendering error:', error));
